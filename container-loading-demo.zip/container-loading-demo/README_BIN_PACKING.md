# Container Layout Optimization - Bin Packing Demo

## Tổng quan

Demo này implement **Bin Packing Algorithm** với logic **Fill Height First** cho hệ thống Container Loading Optimization của Peerless.

### Tính năng chính

- ✅ **Fill đầy chiều cao** của mỗi column/cell trước khi sang column tiếp theo
- ✅ **Một cell chứa NHIỀU ITEMS** stack lên nhau (vertical stacking)
- ✅ **Output format**: `1A+1B+3C+9D+1E+5F` (aggregate nhiều items trong 1 cell)
- ✅ **Pre Pack**: Vertical stacking only (Zone A-N)
- ✅ **Carton**: Flexible packing, maximize items (Zone O-K2)
- ✅ **Group columns thành rows** theo height

## Cấu trúc Files

```
container-loading-demo/
├── backend/
│   ├── item_flattener.py          # Convert case_packs → flat items
│   ├── bin_packing_algorithm.py    # Core bin packing logic
│   ├── layout_optimizer.py        # Main optimizer + row grouping
│   ├── grid_config.py             # Grid dimensions & zones
│   ├── demo_api_bin_packing.py    # FastAPI server
│   ├── test_bin_packing.py        # Test script
│   └── test_data_3d.json          # Sample data
└── frontend/
    └── demo_bin_packing.html      # Web UI demo
```

## Cách chạy Demo

### 1. Backend API Server

```bash
cd container-loading-demo/backend
python demo_api_bin_packing.py
```

Server sẽ chạy tại: `http://localhost:8000`

### 2. Test với Command Line

```bash
# Test health check
curl http://localhost:8000/health

# Test với data mẫu
python test_bin_packing.py
```

### 3. Web UI Demo

Mở file `frontend/demo_bin_packing.html` trong browser để test với giao diện web.

## API Endpoints

### GET /health
```json
{
  "status": "ok",
  "version": "2.0.0", 
  "algorithm": "bin_packing"
}
```

### POST /calculate
**Input:**
```json
{
  "items": [
    {
      "material": "BTAHV-H5B0036",
      "packing_method": "PRE_PACK",
      "case_packs": [
        {
          "case_pack": "AZ",
          "grid_distribution": {
            "A": {"count": 1},
            "B": {"count": 1}
          }
        }
      ]
    }
  ]
}
```

**Output:**
```json
{
  "success": true,
  "layout": {
    "rows": [
      {
        "row": 1,
        "height": 34.5,
        "cells": [
          {
            "cell": 1,
            "content": "1A+1B+3C+9D",
            "total_boxes": 14,
            "items": [
              {"id": "A", "count": 1},
              {"id": "B", "count": 1},
              {"id": "C", "count": 3},
              {"id": "D", "count": 9}
            ],
            "columns": ["A"],
            "position": {"x": 0, "y": 0, "z": 0},
            "dimensions": {"width": 19, "length": 34, "height": 101.25}
          }
        ]
      }
    ],
    "summary": {
      "total_boxes": 398,
      "space_used": 210,
      "space_remaining": 263,
      "utilization_rate": 39.52
    }
  },
  "input_summary": {
    "total_items": 6,
    "prepack_items": 2,
    "carton_items": 4
  }
}
```

## Algorithm Logic

### 1. Item Flattening
- Convert `case_packs` structure thành flat list của individual items
- Mỗi item có: `id`, `material`, `case_pack`, `height`, `packing_method`, `priority`

### 2. Bin Packing
- **First Fit Decreasing** algorithm
- Sort items by priority (PRE_PACK > CARTON) và height (tallest first)
- **Pre Pack Zone (A-N)**: Vertical stacking only
- **Carton Zone (O-K2)**: Flexible packing, maximize items

### 3. Height Filling
- Fill đầy chiều cao của mỗi column trước khi sang column tiếp theo
- Stack multiple items trong cùng 1 column
- Buffer 0.5 inches giữa các layers

### 4. Output Aggregation
- Format: `1A+1B+3C+9D+1E+5F`
- Group columns thành rows theo height
- Row 1: Height 34.5" (columns A-F)
- Row 2: Height 26.5" (columns G-M)
- etc.

## Test Results

Với data mẫu từ `test_data_3d.json`:

```
=== RESULTS ===
Success: True
Total boxes: 398
Space utilization: 39.52%

=== ROW LAYOUT ===
Row 1 (Height 34.5"):
  Cell 1: 6M+1S+1D2 (8 boxes)
  Cell 2: 7S+1D2 (8 boxes)
  Cell 3: 7S+1W (8 boxes)
  Cell 4: 6S+1Y+1W (8 boxes)
  Cell 5: 7Y+1W (8 boxes)
  Cell 6: 2Y+6J+1B (9 boxes)

Row 2 (Height 26.5"):
  Cell 1: 8J+1W (9 boxes)
  Cell 2: 4J+1L+3X+1W (9 boxes)
  Cell 3: 3X+2W+2C2+3K+1T (11 boxes)
  ...
```

## Success Criteria ✅

- ✅ Output format match hình: `1A+1B+3C+9D+1E+5F`
- ✅ Fill đầy height mỗi cell trước khi sang cell mới
- ✅ Pre Pack: Vertical stacking only
- ✅ Carton: Flexible, maximize items
- ✅ Rows grouped by height
- ✅ Total: 398 boxes (match actual data)

## Next Steps

1. **UI Enhancement**: Cải thiện giao diện web để hiển thị layout đẹp hơn
2. **3D Visualization**: Thêm Three.js để visualize 3D layout
3. **Excel Integration**: Parser để đọc Excel input
4. **Performance**: Optimize algorithm cho large datasets
5. **Validation**: Thêm business rules validation

## Troubleshooting

### Server không start được
```bash
# Install dependencies
pip install fastapi uvicorn pydantic

# Check port 8000 có bị chiếm không
netstat -an | findstr :8000
```

### API trả về error
- Kiểm tra JSON format input
- Đảm bảo `packing_method` là "PRE_PACK" hoặc "CARTON"
- Kiểm tra `grid_distribution` có đúng column names (A-K2)

### Test script lỗi
```bash
# Chạy từ đúng directory
cd container-loading-demo/backend
python test_bin_packing.py
```
