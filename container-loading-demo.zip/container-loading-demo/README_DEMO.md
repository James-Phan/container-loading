# Container Layout Algorithm Demo

Demo thuật toán sắp xếp layout container cho khách hàng Peerless.

## Mục tiêu Demo

- Test thuật toán sắp xếp layout với quy tắc Peerless
- Validate logic Pre Pack trước, Carton sau
- Kiểm tra grid placement algorithm
- Demo với data mẫu thực tế

## Cấu trúc Project

```
container-loading-demo/
├── backend/
│   ├── demo_layout_algorithm.py    # Core algorithm
│   ├── demo_api.py                 # FastAPI endpoints
│   ├── test_algorithm.py           # Test script
│   ├── test_data.json              # Sample data
│   └── requirements.txt            # Dependencies
├── frontend/
│   └── demo.html                   # Simple UI
└── README_DEMO.md                  # This file
```

## Setup & Installation

### 1. Tạo Virtual Environment

```bash
cd container-loading-demo
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 2. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 3. Test Algorithm (Console)

```bash
python test_algorithm.py
```

### 4. Run API Server

```bash
uvicorn demo_api:app --reload
```

API sẽ chạy tại: http://localhost:8000

### 5. Open Frontend

Mở file `frontend/demo.html` trong browser hoặc serve qua HTTP server.

## API Endpoints

### POST /calculate
Tính toán layout từ danh sách items.

**Request:**
```json
{
    "items": [
        {
            "purchasing_doc": "4900145614",
            "material": "BTAHV-H5B0036",
            "building_door": "MIL1",
            "packing_method": "PRE_PACK",
            "height": 25,
            "carton_count": 14
        }
    ]
}
```

**Response:**
```json
{
    "success": true,
    "layout": {
        "grid": {
            "A": 1, "B": 1, "E": 3, "F": 9, ...
        },
        "items_processed": 1
    },
    "validation": {
        "is_valid": true,
        "errors": [],
        "warnings": [],
        "statistics": {...}
    },
    "summary": {
        "total_cartons": 14,
        "columns_used": 4,
        "utilization_rate": 0.11,
        ...
    }
}
```

### GET /test-data
Lấy sample data để test.

### GET /grid-info
Lấy thông tin về grid (37 cột, zones, etc.).

### POST /validate
Validate layout mà không tính toán.

## Algorithm Logic

### 1. Grid Layout
- **37 cột**: A, B, C, ..., Z, A2, B2, ..., K2
- **Pre Pack Zone**: A-N (14 cột) - ưu tiên cao nhất
- **Carton Zone**: O-K2 (23 cột) - ưu tiên thấp hơn

### 2. Placement Rules
- Pre Pack items được đặt vào zone A-N trước
- Carton items được đặt vào zone O-K2 sau
- Xếp từ trái sang phải trong mỗi zone
- Tính toán capacity dựa trên height của item

### 3. Validation
- Kiểm tra tổng số cartons match với input
- Kiểm tra zone separation (Pre Pack vs Carton)
- Kiểm tra height constraints (max 102 inches)
- Kiểm tra grid boundaries

## Test Cases

### Sample Data
File `test_data.json` chứa 6 items:
- 2 Pre Pack items (PO 4900145614)
- 4 Carton items (PO 4900147211-4900147263)

### Expected Results
- Pre Pack items → Zone A-N
- Carton items → Zone O-K2
- Total cartons: 430
- Utilization rate: ~11.6%

## Frontend Features

### Grid Visualization
- 37 cột với color coding
- Pre Pack zone (green)
- Carton zone (blue)
- Empty columns (gray)

### Statistics Dashboard
- Total cartons placed
- Columns used
- Utilization rate
- Zone-specific metrics

### Validation Display
- Success/Error indicators
- Warning messages
- Detailed statistics

## Troubleshooting

### Common Issues

1. **API không chạy**
   - Kiểm tra port 8000 có bị chiếm không
   - Chạy `uvicorn demo_api:app --reload --port 8001`

2. **CORS Error**
   - API đã enable CORS cho tất cả origins
   - Nếu vẫn lỗi, mở HTML file qua HTTP server

3. **JSON Parse Error**
   - Kiểm tra format JSON input
   - Sử dụng "Load Sample Data" để test

4. **Algorithm không đúng**
   - Kiểm tra console output
   - Chạy `python test_algorithm.py` để debug

### Debug Mode

Để debug algorithm:
```bash
cd backend
python -c "
from demo_layout_algorithm import LayoutAlgorithmDemo
import json

with open('test_data.json') as f:
    data = json.load(f)

algo = LayoutAlgorithmDemo()
result = algo.place_items(data['items'])
print('Grid:', result)
"
```

## Next Steps

Sau khi demo OK:

1. **Refine Algorithm**
   - Cải thiện placement logic
   - Thêm optimization algorithms
   - Handle edge cases tốt hơn

2. **Add Features**
   - 3D visualization
   - Export to Excel
   - More validation rules

3. **Build Full System**
   - Database integration
   - Authentication
   - Production deployment
   - Full UI với React/TypeScript

## Performance

- **Algorithm**: < 1 second cho 100 items
- **API Response**: < 2 seconds
- **Memory**: < 50MB
- **Concurrent Users**: 10+ (demo mode)

## Support

Nếu có vấn đề:
1. Kiểm tra console logs
2. Test với sample data
3. Verify API endpoints
4. Check browser console for errors
