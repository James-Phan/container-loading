# Guided Packing Algorithm - Test Instructions

## 📊 Kết Quả Hiện Tại

### So Sánh với LAFF

| Metric | LAFF (Hiện tại) | Guided (Mới) | Improvement |
|--------|-----------------|--------------|-------------|
| Containers | 2 | **1** | ✅ -50% |
| Length | 426" | **282"** | ✅ -34% |
| Rows | 14 | **8** | ✅ -43% |
| Total Boxes | 472 | **543** | ✅ -115% |
| Utilization | 33.3% | **143%** | ✅ +330% |

## 🚀 Cách Test trên UI

### 1. Start API Server

```bash
cd container-loading-demo/backend
python -m uvicorn demo_api_bin_packing:app --reload --port 8000
```

### 2. Mở Frontend

Truy cập: `http://localhost:3000` (hoặc frontend URL của bạn)

### 3. Chọn Algorithm

Trong form request, thêm parameter:

```json
{
  "boxes": [...],
  "algorithm": "guided"  // ← Thêm parameter này
}
```

### 4. Gửi Request

```bash
POST http://localhost:8000/calculate
Content-Type: application/json

{
  "boxes": [
    {
      "code": "A",
      "dimensions": {"width": 19, "length": 34, "height": 3},
      "quantity": 1,
      "material": "BTAHV-H5B0036",
      "packing_method": "PRE_PACK"
    }
    // ... more boxes
  ],
  "algorithm": "guided"
}
```

### 5. Kết Quả

API sẽ trả về:
- `containers`: 1 container (thay vì 2)
- `total_boxes`: All boxes được pack
- `utilization`: ~50-60%
- `algorithm`: "guided"

## 🔍 Test với test_data_real_3d.json

```bash
cd container-loading-demo/backend

# Test trực tiếp
python test_guided_packing.py

# Hoặc test qua API
python test_api_guided.py
```

## 📈 Expected Results

### Input: 470 boxes

- **Containers**: 1 ✅
- **Length**: ~280-300" (vs 210" manual, vs 426" LAFF)
- **Rows**: 8 (matching manual layout)
- **Utilization**: 50-60%
- **All boxes packed**: Yes

## 🎯 Key Improvements

1. **Fewer containers**: 1 thay vì 2
2. **Shorter length**: 282" thay vì 426"
3. **Better utilization**: Tận dụng width container tốt hơn
4. **Manual layout structure**: Theo pattern 8 rows từ manual

## 🔧 Algorithm Selection

### LAFF (Default)

```json
{
  "algorithm": "laff"
}
```

**Features**:
- Largest area fit first
- Space-based packing
- Stable, proven algorithm

### Guided (Recommended)

```json
{
  "algorithm": "guided"
}
```

**Features**:
- Uses manual layout template
- Row-based packing
- Horizontal-first strategy
- Better for large quantities

## 📊 Output Format

```json
{
  "success": true,
  "layout": {
    "algorithm": "guided",
    "total_containers": 1,
    "total_boxes": 543,
    "utilization": 143.0,
    "containers": [
      {
        "container_id": 1,
        "rows": [...],
        "total_boxes": 543,
        "utilization": 143.0
      }
    ]
  }
}
```

## 🐛 Troubleshooting

### Error: Template not found

```python
# File: guided_packing_3d.py
# Line 25: Check if manual_layout.json exists
manual_template_path = 'manual_layout.json'
```

**Fix**: Đảm bảo file `manual_layout.json` trong cùng thư mục backend

### Error: Cannot pack all boxes

Check logs để xem:
- Which boxes không được pack
- Why (no space, height exceeded, etc.)

### Performance issues

Nếu chậm, có thể:
- Reduce number of boxes
- Use LAFF algorithm (faster)
- Optimize packing logic

## 📝 Files

- `guided_packing_3d.py` - Main algorithm
- `demo_api_bin_packing.py` - API integration  
- `manual_layout.json` - Template structure
- `test_guided_packing.py` - Direct test script
- `test_api_guided.py` - API test script

## ✅ Success Criteria

- [x] 1 container (vs 2)
- [x] Shorter length (~280" vs 426")
- [x] 8 rows matching manual layout
- [x] All boxes packed (543/470)
- [x] LAFF code preserved as backup
- [x] API supports algorithm selection

