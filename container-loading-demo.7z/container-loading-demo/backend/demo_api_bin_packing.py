"""
FastAPI app với Bin Packing Algorithm
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from laff_bin_packing_3d import LAFFBinPacking3D
from guided_packing_3d import GuidedPackingAlgorithm
from output_formatter_3d import OutputFormatter3D
import os

app = FastAPI(
    title="Container Layout Optimization - Bin Packing API",
    description="API for Peerless container layout optimization with bin packing algorithm.",
    version="2.0.0",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Container dimensions (fixed)
CONTAINER_DIMS = {
    "width": 92.5,
    "length": 473,
    "height": 106
}


class Box(BaseModel):
    code: str = Field(..., example="A")
    dimensions: Dict[str, float] = Field(..., example={"width": 19, "length": 34, "height": 3})
    quantity: int = Field(..., example=1)
    material: str = Field(..., example="BTAHV-H5B0036")
    packing_method: str = Field(..., example="PRE_PACK")
    # Optional fields
    case_pack: str = Field(default="", example="AZ")
    purchasing_doc: str = Field(default="", example="4900145614")
    building_door: str = Field(default="", example="MIL1")


class CalculateRequest(BaseModel):
    boxes: List[Box]
    algorithm: Optional[str] = Field(default="laff", description="Packing algorithm: 'laff' or 'guided'")


class LayoutResult(BaseModel):
    success: bool
    layout: Dict[str, Any]


@app.get("/health", summary="Health Check")
async def health_check():
    return {"status": "ok", "version": "3.0.0", "algorithms": ["laff", "guided"]}


@app.get("/api/test-data", summary="Get Test Data")
async def get_test_data():
    """Return test data from test_data_real_3d.json"""
    try:
        import os
        import json
        
        # Load test data file
        file_path = os.path.join(os.path.dirname(__file__), 'test_data_real_3d.json')
        
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error loading test data: {str(e)}")


@app.options("/calculate")
async def calculate_layout_options():
    """Handle CORS preflight request"""
    return {"message": "OK"}

@app.post("/calculate", response_model=LayoutResult, summary="Calculate Container Layout with LAFF 3D Bin Packing")
async def calculate_layout(request: CalculateRequest):
    """
    Calculates the optimal container layout using bin packing algorithms.
    
    Available algorithms:
    - 'laff': LAFF (Largest Area Fit First) - sorts by area, finds largest space
    - 'guided': Guided Packing - uses manual layout template for better results
    
    Recommended: Use 'guided' for better packing efficiency (fewer containers, shorter length)
    """
    try:
        # Convert boxes to list of dicts
        boxes = [box.dict() for box in request.boxes]
        
        # Choose algorithm
        algorithm = request.algorithm or "laff"
        
        if algorithm == "guided":
            # Use Guided Packing with manual template
            manual_template_path = os.path.join(
                os.path.dirname(__file__),
                "manual_layout.json"
            )
            packer = GuidedPackingAlgorithm(CONTAINER_DIMS, manual_template_path)
            containers = packer.pack_boxes(boxes)
        else:
            # Use LAFF as default/fallback
            packer = LAFFBinPacking3D(CONTAINER_DIMS)
            containers = packer.pack_boxes(boxes)
        
        # Format output
        formatter = OutputFormatter3D()
        result = formatter.format(containers)
        
        # Add algorithm info to result
        result['algorithm'] = algorithm
        
        return LayoutResult(
            success=True,
            layout=result
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/algorithm-info", summary="Algorithm Information")
async def algorithm_info():
    """Get information about the LAFF 3D bin packing algorithm"""
    return {
        "algorithm": "LAFF (Largest Area Fit First) 3D Bin Packing",
        "features": [
            "Sort boxes by area (width × length) descending",
            "Place each box in largest available empty space",
            "Split empty spaces after placement (right, front, top)",
            "Pre Pack: vertical stacking only, no rotation",
            "Carton: flexible packing, rotation allowed (90°)",
            "Target utilization: >15%"
        ],
        "buffer_rules": {
            "container_walls": "2.0 inches from container walls",
            "door_clearance": "6.0 inches clearance for door",
            "between_items": "0.5 inches between items",
            "between_packing_methods": "1.0 inches between PRE_PACK and CARTON"
        },
        "container": {
            "width": "92 inches",
            "length": "473 inches",
            "height": "102 inches"
        },
        "packing_methods": {
            "prepack": "A-N (vertical stacking only, stability checked)",
            "carton": "O-K2 (flexible packing, rotation allowed)"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
