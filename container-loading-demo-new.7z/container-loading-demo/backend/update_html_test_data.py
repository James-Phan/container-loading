"""
Update HTML file with new test data from test_data_real_3d.json
"""

import json

# Load new test data
with open('test_data_real_3d.json', 'r') as f:
    test_data = json.load(f)

# Format as JavaScript object
js_data = json.dumps(test_data, indent=20)
js_data = js_data.replace('"', '\\"').replace('\n', '\\n')

# Read HTML
with open('../frontend/demo_3d_bin_packing.html', 'r', encoding='utf-8') as f:
    html_content = f.read()

# Find and replace loadTestData function
# This is a simple replacement - you may need to adjust based on actual HTML structure
print("Test data loaded:")
print(f"Total boxes: {sum(box['quantity'] for box in test_data['boxes'])}")
print(f"Container: {test_data['container']}")

# For now, just create a JS file that can be imported
js_content = f"""
// Auto-generated test data from test_data_real_3d.json
const testData = {json.dumps(test_data, indent=2)};
"""

with open('../frontend/test_data.js', 'w') as f:
    f.write(js_content)

print("✅ Created test_data.js")
print("📝 You can now update HTML to use this file")

