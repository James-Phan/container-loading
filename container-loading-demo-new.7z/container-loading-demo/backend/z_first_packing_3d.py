"""
Z-First Packing Algorithm - Fill height (Z-axis) before width (X-axis)

Strategy:
1. Pack boxes stacking vertically (Z-axis: 0→106") before moving horizontally (X-axis: 0→92.5")
2. Maximize height utilization at each X position
3. When Z axis is full, move to next X position
4. Create rows dynamically based on available boxes
"""

from typing import List, Dict, Any
from laff_bin_packing_3d import LAFFBinPacking3D


class ZFirstPackingAlgorithm(LAFFBinPacking3D):
    """
    Z-First Packing: Fill height (Z-axis) before width (X-axis)
    
    Strategy:
    - Start at (x=0, z=0)
    - Stack boxes vertically (increase Z)
    - When Z full (≥106") → move right (increase X, reset Z)
    - When X full (≥92.5") → move to next row (increase Y)
    
    Inherits from LAFFBinPacking3D for base functionality.
    """
    
    def __init__(self, container_dims: Dict[str, float]):
        super().__init__(container_dims)
    
    def pack_boxes(self, boxes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Pack boxes using Z-first strategy
        
        Args:
            boxes: List of boxes to pack
            
        Returns:
            List[Dict]: Container with packed boxes
        """
        # Initialize container
        self._new_container()
        
        # Track remaining boxes counts
        remaining_counts = {}
        for box in boxes:
            qty = box.get('quantity', 1)
            if qty == 0:
                continue
            key = (box.get('code', ''), box.get('material', ''), 
                   box.get('purchasing_doc', ''), box.get('packing_method', ''))
            remaining_counts[key] = qty
        
        print(f"DEBUG: Total unique boxes: {len(remaining_counts)}")
        print(f"DEBUG: Total quantity: {sum(remaining_counts.values())}")
        
        # Track position as we pack rows
        current_y = self.BUFFER_RULES['door_clearance']  # Start after door clearance
        row_number = 1
        
        while True:
            # Check if any boxes remain
            total_remaining = sum(remaining_counts.values())
            if total_remaining == 0:
                break
            
            # Get available boxes
            available_boxes = []
            for box in boxes:
                key = (box.get('code', ''), box.get('material', ''), 
                       box.get('purchasing_doc', ''), box.get('packing_method', ''))
                if key in remaining_counts and remaining_counts[key] > 0:
                    box_copy = box.copy()
                    box_copy['quantity'] = remaining_counts[key]
                    available_boxes.append(box_copy)
            
            if not available_boxes:
                break
            
            print(f"Row {row_number}: {len(available_boxes)} box types, {total_remaining} boxes available")
            
            # Pack boxes in this row using Z-first strategy
            placed_boxes = self.pack_row_z_first(
                available_boxes, current_y, self.container['height'], self.container['width']
            )
            
            if not placed_boxes:
                break
            
            # Remove placed boxes from remaining_counts
            placed_by_type = {}
            for placed_box in placed_boxes:
                code = placed_box.get('code', 'UNKNOWN')
                material = placed_box.get('material', '')
                key = None
                for orig_box in boxes:
                    if orig_box.get('code') == code and orig_box.get('material') == material:
                        key = (orig_box.get('code', ''), orig_box.get('material', ''),
                               orig_box.get('purchasing_doc', ''), orig_box.get('packing_method', ''))
                        break
                if key:
                    placed_by_type[key] = placed_by_type.get(key, 0) + 1
            
            for key, count in placed_by_type.items():
                if key in remaining_counts:
                    remaining_counts[key] -= count
                    if remaining_counts[key] < 0:
                        remaining_counts[key] = 0
            
            print(f"  -> Placed {len(placed_boxes)} boxes")
            print(f"  -> Remaining: {sum(remaining_counts.values())} boxes")
            
            # Add placed boxes to container
            for box in placed_boxes:
                self.current_container['boxes'].append(box)
            
            # Calculate max height in this row (for visualization only)
            max_z = max(box['position']['z'] + box['dimensions']['height'] 
                       for box in placed_boxes) if placed_boxes else 0
            
            # Calculate actual Y position used by this row
            max_length = max(box['dimensions']['length'] for box in placed_boxes) if placed_boxes else 34.0
            current_y += max_length
            
            print(f"  -> Row height: {max_z:.1f}\" Z-axis, Y position now: {current_y:.1f}\"")
            
            row_number += 1
            
            # Safety check: don't exceed container length
            if current_y >= self.container['length']:
                print(f"WARNING: Stopping due to container length limit")
                break
        
        return self.containers
    
    def pack_row_z_first(self, boxes: List[Dict], row_y: float, container_height: float, 
                         container_width: float) -> List[Dict]:
        """
        Pack row using Z-first strategy
        
        Strategy:
        1. Fill Z-axis first (bottom to top: 0 → 106")
        2. When Z full → increase X (move right), reset Z
        3. When X full → stop (row is full)
        
        This maximizes height utilization before spreading horizontally.
        
        Args:
            boxes: List of boxes to pack
            row_y: Y position for this row
            container_height: Max height (Z-axis)
            container_width: Max width (X-axis)
            
        Returns:
            List[Dict]: Placed boxes
        """
        placed_boxes = []
        
        # Expand all boxes by quantity
        expanded_boxes = []
        for box in boxes:
            qty = int(box.get('quantity', 1))
            if qty <= 0:
                continue
            for _ in range(qty):
                expanded_boxes.append(box.copy())
        
        # Track position in row - START FILLING Z FIRST
        current_x = 0.0
        current_z = 0.0
        column_max_width = 0.0  # Track max width in current column
        
        for box in expanded_boxes:
            best_orientation = None
            fits_current = False
            
            # Try all orientations and pick the one with smallest width that fits
            for orientation in self.get_all_orientations(box):
                box_w = orientation['width']
                box_h = orientation['height']  # Z-axis height
                
                # Check if fits in container dimensions
                if box_w > container_width or box_h > container_height:
                    continue
                
                # Check if fits at current position (KEY: check Z first!)
                if current_z + box_h <= container_height and current_x + box_w <= container_width:
                    if best_orientation is None or box_w < best_orientation['width']:
                        best_orientation = orientation
                        fits_current = True
            
            # If doesn't fit at current Z position, move to next column (X)
            if not fits_current:
                current_x += column_max_width
                current_z = 0.0
                column_max_width = 0.0
                
                # Try again at new column
                for orientation in self.get_all_orientations(box):
                    box_w = orientation['width']
                    box_h = orientation['height']
                    
                    if box_w > container_width or box_h > container_height:
                        continue
                    
                    if current_z + box_h <= container_height and current_x + box_w <= container_width:
                        if best_orientation is None or box_w < best_orientation['width']:
                            best_orientation = orientation
                            fits_current = True
            
            # Place box if we found a fit
            if best_orientation and fits_current:
                placed_box = {
                    'code': box.get('code', 'UNKNOWN'),
                    'dimensions': best_orientation,
                    'position': {
                        'x': current_x,
                        'y': row_y,
                        'z': current_z
                    },
                    'material': box.get('material', ''),
                    'packing_method': box.get('packing_method', 'CARTON')
                }
                placed_boxes.append(placed_box)
                
                # Update position for next box
                box_w = best_orientation['width']
                box_h = best_orientation['height']
                
                # KEY: Increase Z first (stack up)
                current_z += box_h
                column_max_width = max(column_max_width, box_w)
                
                # If Z exceeds height, move to next column (X)
                if current_z >= container_height:
                    current_x += column_max_width
                    current_z = 0.0
                    column_max_width = 0.0
            else:
                # Can't fit this box in current row, stop
                break
        
        return placed_boxes
    
    def get_all_orientations(self, box: Dict) -> List[Dict]:
        """
        Generate all orientations hợp lệ cho box
        
        CARTON: 6 orientations (xoay tự do)
        PRE_PACK: 2 orientations (chỉ xoay ngang, không lật đứng)
        
        Args:
            box: Box dict with dimensions and packing_method
            
        Returns:
            List[Dict]: [{width, length, height}, ...]
        """
        w, l, h = box['dimensions']['width'], box['dimensions']['length'], box['dimensions']['height']
        packing_method = box.get('packing_method', 'CARTON')
        
        if packing_method == 'PRE_PACK':
            # PRE_PACK: chỉ 2 orientations (không lật)
            return [
                {'width': w, 'length': l, 'height': h},
                {'width': l, 'length': w, 'height': h}
            ]
        else:
            # CARTON: 6 orientations
            return [
                {'width': w, 'length': l, 'height': h},
                {'width': w, 'length': h, 'height': l},
                {'width': l, 'length': w, 'height': h},
                {'width': l, 'length': h, 'height': w},
                {'width': h, 'length': w, 'height': l},
                {'width': h, 'length': l, 'height': w}
            ]
